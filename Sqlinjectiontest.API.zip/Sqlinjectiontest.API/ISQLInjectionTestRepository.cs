﻿namespace Sqlinjectiontest.API
{
    public interface ISQLInjectionTestRepository
    {
        Task<bool> DisposableTableExistsAsync(CancellationToken cancellationToken = default);
        Task ResetAsync(CancellationToken cancellationToken = default);
        Task<IReadOnlyList<SQLInjectionTestUser>> SearchSafeAsync(string name, CancellationToken cancellationToken = default);
        Task<IReadOnlyList<SQLInjectionTestUser>> SearchUnsafeAsync(string name, CancellationToken cancellationToken = default);
    }
}